"""Evolé core subsystem modules."""
