# Astrid (Gradient ADK) – Project Docs Bundle

This folder contains the documentation pack for **Astrid** (Devpost/Gradient competition).

## Key decisions (locked)
- Product identity: **Autonomous Executive + Life Admin**
- Memory: **Opt-out** (on by default; user can disable)
- Camera astronomy demo: **Live camera capture**
- Astronomy identification: **Hybrid (fast match → plate solve fallback)**
- Legal behavior: **NDA auto-drafted only when Healthcare mode triggers**
- Demo confirmation: **Always-on** (every response requires ledger confirmation in demo mode)

## Open item
- Exact model IDs for GPT‑5 mini + GPT‑5 from: `doctl genai list-models -o json`
  - Update env vars:
    - `ASTRID_MODEL_BASE=<exact-id>`
    - `ASTRID_MODEL_PREMIUM=<exact-id>`

## Repo structure recommendation
See `docs/00_README.md` in this bundle for full ToC.
