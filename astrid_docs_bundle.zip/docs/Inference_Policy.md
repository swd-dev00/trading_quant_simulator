# Inference Policy (Option B: Two-tier)

## Summary
- Base model (cheap/fast): GPT‑5 mini
- Premium model (quality): GPT‑5
- Hard rule: Never call premium model before ledger confirmation when confirmation is required.

## Routing table
- General Executive: base (final may use premium only in Presentation Mode)
- Schoolwork Integrity: base
- Camera Astronomy explanations: base (optional premium in Presentation Mode)
- Healthcare Governance:
  - Pre-confirm: NDA + PHI question (no premium)
  - Post-confirm: premium for ops analysis memo

## Token caps (recommended)
- General Executive: max_output_tokens=900
- Schoolwork: 700
- Astronomy explanation: 550
- Healthcare final (premium): 1200
Temperature: 0.2 (all)

## Environment variables (update with exact model IDs)
ASTRID_MODEL_BASE=<gpt-5-mini-id>
ASTRID_MODEL_PREMIUM=<gpt-5-id>
