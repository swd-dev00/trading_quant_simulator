# Demo Script (Minute-by-minute)

## 0:00–0:20 Hook + identity
Show Astrid: Autonomous Executive + Life Admin, opt-out memory, governed modes, always-on demo ledger confirmation.

## 0:20–0:55 Progressive personalization + accountability
Ask for a weekly plan (2 options). Show “What Astrid remembers” ledger viewer. Edit one preference live.

## 0:55–1:55 Live camera astronomy (Hybrid)
Capture a sky frame. Show fast pass output then plate solve fallback (if confidence below threshold). Show confidence + fallback flag.

## 1:55–2:35 Schoolwork Integrity Mode
Paste a quiz-style prompt. Astrid provides tutoring steps/hints, not final answers.

## 2:35–3:35 Healthcare Governance Mode
Paste a clinic throughput prompt. Astrid outputs NDA first, asks PHI question, then (post-confirm) produces ops memo.

## 3:35–4:30 Proof: traces + evaluations
Show mode routing span, NDA tool span, KB retrieval span, and evaluation run results.
