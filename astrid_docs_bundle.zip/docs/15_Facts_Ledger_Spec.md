# Facts Ledger Spec (Ledger: A, Demo Confirmation: A)

## Purpose
Make Astrid’s decision inputs explicit and user-owned. Prevent hidden assumptions, personalization drift, and presentation oddities.

## Visibility
- UI toggle: Memory On/Off (opt-out)
- Button: “What Astrid remembers” → ledger viewer
- Edit and delete per item
- Clear ledger option

## Data model (authoritative)
- core_profile: role, organization, industry
- preferences: format_style, option_count_preference, brevity_level
- constraints: budget_range, timeline_constraints, risk_tolerance
- recurring_goals: list[str]
- professional_boundaries: healthcare_mode_enabled, schoolwork_integrity_enforced
- astronomy_preferences: confidence_threshold, preferred_detail_level
- ledger_version, last_user_confirmed

## Prohibited ledger content
- Sensitive identifiers (SSN, MRN, DOB, addresses)
- Credentials / tokens
- Patient records
- Financial account numbers

## Demo confirmation
In demo_mode, every response must include:
- “Facts I’m Using” block (ledger summary)
- requires_confirmation=true
Client must re-submit with confirmed=true to finalize.

## High-stakes confirmation (non-demo)
Confirmation required for:
- legal drafts
- healthcare ops/performance analysis
- public-facing content
- strategy memos / contractual material
